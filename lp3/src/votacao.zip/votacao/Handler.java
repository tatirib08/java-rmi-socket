package votacao;
import tcp.Contato;
import tcp.ListaAgenda;

import java.io.InputStream;
import java.net.Socket;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

public class Handler implements Runnable
{
    private Socket clienteSocket;
    private Votos votacao = new Votos();
    public Socket getClienteSocket()
    {
        return this.clienteSocket;
    }
    public Handler(Socket socket, Votos votacao)
    {
        this.clienteSocket = socket;
        this.votacao = votacao;

    }
    public void setClienteSocket(Socket cliente)
    {
        this.clienteSocket = cliente;
    }

    @Override
    public void run()
    {
        try
        {
            ObjectOutputStream output = new ObjectOutputStream(clienteSocket.getOutputStream());
            ObjectInputStream input = new ObjectInputStream(clienteSocket.getInputStream());

            int voto = (int)input.readObject();

            votacao.atualizarPlacar(voto);
            int resultado = votacao.mostrarResultado();

//            output.flush();
            output.writeObject(resultado);
            output.close();
            input.close();

            /* teste */
//            agenda.printLista();
//            System.out.println("mensagem do cliente:"+solicitacao);
            System.out.println("Thread: ");
            System.out.println(Thread.currentThread().getName());
        }
        catch (Exception e)
        {
            System.out.println(e.getMessage());
        }
    }
}
