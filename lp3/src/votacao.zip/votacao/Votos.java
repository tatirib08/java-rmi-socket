package votacao;

public class Votos
{
    public Votos()
    {

    }

    private int op1=0, op2=0;
    public void setOp1(int op)
    {
        this.op1 = op;
    }

    public int getOp1()
    {
        return this.op1;
    }

    public void setOp2(int op)
    {
        this.op2 = op;
    }

    public int getOp2() {
        return op2;
    }

    public  synchronized void atualizarPlacar(int op)
    {
        switch (op)
        {
            case 1:
                setOp1(this.op1+=1);
                break;

            case 2:
                setOp2(this.op2+=1);
                break;
        }
    }

    public synchronized int mostrarResultado()
    {
        System.out.println("Opção 1: "+ getOp1() + " votos");

        System.out.println("Opção 2: "+ getOp2() + " votos");

        if (getOp1() > getOp2())
        {
            return 1;
        }
        else if (getOp2() > getOp1())
        {
            return 2;
        }
        else
        {
            return 0;
        }
    }

    public void menu()
    {
        System.out.println("-----VOTAÇÃO-----");
        System.out.println("Qual é o melhor irmão Salvatore de The Vampire Diares?");
        System.out.println("1. Stefan Salvatore.");
        System.out.println("2. Damon Salvatore.");

    }
}
